/**
 * 小龙虾 P2P Skill 入口
 * 处理用户的 P2P 相关命令
 */

const p2p = require('./p2p');

let p2pServerRunning = false;

// 解析命令
async function handleCommand(command, args, sendMessage) {
  const cmd = command.toLowerCase().trim();
  
  // 启动 P2P 服务器
  if (cmd === '启动 p2p' || cmd === '启动p2p') {
    if (p2pServerRunning) {
      return 'P2P 服务器已经在运行了';
    }
    try {
      const config = p2p.loadConfig();
      await p2p.startServer(config.port, (fromId, fromNickname, content) => {
        // 收到消息时通知用户
        sendMessage(`💬 收到来自 ${fromNickname} 的消息: ${content}`);
      });
      p2pServerRunning = true;
      const info = p2p.getMyInfo();
      return `✅ P2P 服务器已启动！
      
📡 你的信息：
- 昵称: ${info.nickname}
- 端口: ${info.port}
- 设备ID: ${info.deviceId}

⚠️ 把你的 IP:端口 告诉对方，对方就能连接你了`;
    } catch (e) {
      return `❌ 启动失败: ${e.message}`;
    }
  }
  
  // 停止 P2P
  if (cmd === '停止 p2p' || cmd === '停止p2p') {
    if (!p2pServerRunning) {
      return 'P2P 服务器没有运行';
    }
    await p2p.stopServer();
    p2pServerRunning = false;
    return '✅ P2P 服务器已停止';
  }
  
  // 我的 P2P 信息
  if (cmd === '我的 p2p 信息' || cmd === '我的p2p信息' || cmd === 'p2p信息') {
    const info = p2p.getMyInfo();
    
    // 尝试获取外网 IP
    let ip = '请查询';
    try {
      const http = require('http');
      // 这个可能比较慢，简化处理
    } catch (e) {}
    
    return `📡 你的 P2P 信息：

🔹 昵称: ${info.nickname}
🔹 端口: ${info.port}
🔹 设备ID: ${info.deviceId}
🔹 标签: ${info.tags.join(', ') || '未设置'}

📝 告诉对方这个格式: IP:端口
例如: 192.168.1.100:5566`;
  }
  
  // 连接对方
  if (cmd.startsWith('连接 ')) {
    const rest = args.join(' ');
    // 解析 IP:端口 消息
    const match = rest.match(/^(\d+\.\d+\.\d+\.\d+):(\d+)\s+(.+)$/);
    
    if (!match) {
      return `❌ 格式错误！
      
正确格式: 连接 IP:端口 消息
例如: 连接 192.168.1.100:5566 你好

提示：先让对方发给你他的 P2P 信息`;
    }
    
    const [, ip, port, message] = match;
    
    try {
      const result = await p2p.connectAndSend(ip, parseInt(port), message);
      return `✅ 消息已发送给 ${result.nickname}！`;
    } catch (e) {
      return `❌ 连接失败: ${e.message}

可能原因：
- 对方 P2P 服务器未启动
- 网络不通（不在同一局域网）
- 对方防火墙阻止了端口`;
    }
  }
  
  // 我的昵称
  if (cmd.startsWith('我的昵称 ')) {
    const name = args.slice(1).join(' ');
    if (!name) {
      return '请提供昵称，例如：我的昵称 小明';
    }
    const config = p2p.setNickname(name);
    return `✅ 昵称已设置为: ${config.nickname}`;
  }
  
  // 我的标签
  if (cmd.startsWith('我的标签 ')) {
    const tags = args.slice(1).join(' ').split(',').map(t => t.trim()).filter(t => t);
    if (!tags.length) {
      return '请提供标签，例如：我的标签 安装工,上海';
    }
    const config = p2p.setTags(tags);
    return `✅ 标签已设置为: ${config.tags.join(', ')}`;
  }
  
  // 联系人列表
  if (cmd === '联系人列表' || cmd === '联系人') {
    const contacts = p2p.getContacts();
    const list = Object.entries(contacts);
    
    if (!list.length) {
      return '📇 暂无联系人

先尝试连接对方吧：连接 IP:端口 消息';
    }
    
    let text = '📇 联系人列表：\n\n';
    for (const [id, c] of list) {
      const time = new Date(c.lastSeen).toLocaleString('zh-CN');
      text += `🔹 ${c.nickname}\n`;
      text += `   地址: ${c.address}:${c.port}\n`;
      text += `   标签: ${c.tags?.join(', ') || '-'}\n`;
      text += `   最后在线: ${time}\n\n`;
    }
    return text;
  }
  
  // 帮助
  if (cmd === 'p2p 帮助' || cmd === 'p2p帮助') {
    return `🦞 P2P 命令帮助：

📡 基础命令：
- 启动 P2P — 启动服务器
- 停止 P2P — 停止服务器
- 我的 P2P 信息 — 查看自己的信息
- 联系人列表 — 查看已保存的联系人

🔧 个性化：
- 我的昵称 名字 — 设置昵称
- 我的标签 标签1,标签2 — 设置标签

💬 连接：
- 连接 IP:端口 消息 — 连接对方并发送消息

📝 使用流程：
1. 先执行"启动 P2P"
2. 执行"我的 P2P 信息"获取你的地址
3. 通过微信/飞书把地址发给对方
4. 对方连接你`;
  }
  
  return null; // 未识别命令
}

// 导出
module.exports = {
  handleCommand,
};
