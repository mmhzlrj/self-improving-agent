#!/usr/bin/env node
/**
 * 小龙虾 P2P Skill 自动安装脚本
 * 
 * 使用方法：
 * 1. 把 lobster-p2p.zip 放到 ~/.openclaw/workspace/skills/ 目录
 * 2. 告诉小龙虾："安装 P2P"
 */

const fs = require('fs');
const path = require('path');

const SKILLS_DIR = path.join(process.env.HOME || '/Users/lr', '.openclaw/workspace/skills');
const ZIP_NAME = 'lobster-p2p.zip';
const SKILL_NAME = 'lobster-p2p';

async function install(sendMessage) {
  const zipPath = path.join(SKILLS_DIR, ZIP_NAME);
  const targetDir = path.join(SKILLS_DIR, SKILL_NAME);
  
  // 查找 zip 文件
  if (!fs.existsSync(zipPath)) {
    // 也可能在当前目录
    const currentDir = process.cwd();
    const altPath = path.join(currentDir, ZIP_NAME);
    if (fs.existsSync(altPath)) {
      return await installFrom(altPath, sendMessage);
    }
    return '❌ 找不到 lobster-p2p.zip，请先把文件放到 ~/.openclaw/workspace/skills/ 目录';
  }
  
  return await installFrom(zipPath, sendMessage);
}

async function installFrom(zipPath, sendMessage) {
  const targetDir = path.join(SKILLS_DIR, SKILL_NAME);
  
  // 确保 skills 目录存在
  if (!fs.existsSync(SKILLS_DIR)) {
    fs.mkdirSync(SKILLS_DIR, { recursive: true });
  }
  
  // 解压 zip（使用系统 unzip 或 node 简单解压）
  const targetDirExists = fs.existsSync(targetDir);
  
  if (targetDirExists) {
    // 备份旧版本
    const backupDir = targetDir + '.backup.' + Date.now();
    fs.renameSync(targetDir, backupDir);
    console.log('📦 已备份旧版本到:', backupDir);
  }
  
  // 创建目录
  fs.mkdirSync(targetDir, { recursive: true });
  
  // 简单解压（只支持最基本的情况）
  // 实际使用可以用 JSZip 库，但这里用 exec 更简单
  try {
    execSync(`unzip -o "${zipPath}" -d "${targetDir}"`, { stdio: 'pipe' });
  } catch (e) {
    // 如果没有 unzip，尝试用 node 原生方式
    // 这里简化处理，假设文件已经手动解压了
    return '❌ 解压失败，请确保 unzip 已安装，或手动解压 zip 文件到 skills 目录';
  }
  
  // 检查必要的文件
  const requiredFiles = ['p2p.js', 'index.js', 'SKILL.md'];
  for (const file of requiredFiles) {
    if (!fs.existsSync(path.join(targetDir, file))) {
      return `❌ 安装包缺少必要文件: ${file}`;
    }
  }
  
  return `✅ P2P Skill 安装完成！

📝 使用方法：
1. 告诉小龙虾: 启动 P2P
2. 告诉小龙虾: 我的 P2P 信息
3. 把地址发给对方
4. 对方执行: 连接 你的IP:端口 消息`;
}

module.exports = { install };
