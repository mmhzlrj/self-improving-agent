#!/usr/bin/env node
/**
 * 小龙虾 P2P 通信模块
 * TCP 直连，ping 通就发消息
 */

const net = require('net');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const DEFAULT_PORT = 5566;
const CONTACTS_FILE = path.join(__dirname, 'contacts.json');
const CONFIG_FILE = path.join(__dirname, 'config.json');

// 默认配置
const defaultConfig = {
  port: DEFAULT_PORT,
  nickname: '小龙虾-' + Math.random().toString(36).substr(2, 4),
  tags: [],
};

// 加载配置
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_FILE)) {
      return { ...defaultConfig, ...JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8')) };
    }
  } catch (e) {}
  return defaultConfig;
}

// 保存配置
function saveConfig(config) {
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2));
}

// 加载联系人
function loadContacts() {
  try {
    if (fs.existsSync(CONTACTS_FILE)) {
      return JSON.parse(fs.readFileSync(CONTACTS_FILE, 'utf8'));
    }
  } catch (e) {}
  return {};
}

// 保存联系人
function saveContacts(contacts) {
  fs.writeFileSync(CONTACTS_FILE, JSON.stringify(contacts, null, 2));
}

// 生成设备 ID
function generateDeviceId() {
  const idFile = path.join(__dirname, '.device-id');
  try {
    if (fs.existsSync(idFile)) {
      return fs.readFileSync(idFile, 'utf8').trim();
    }
  } catch (e) {}
  const id = crypto.randomBytes(16).toString('hex');
  fs.writeFileSync(idFile, id);
  return id;
}

const DEVICE_ID = generateDeviceId();
let server = null;
let messageHandler = null;

// 创建 TCP 服务器
function startServer(port, onMessage) {
  return new Promise((resolve, reject) => {
    server = net.createServer((socket) => {
      // 对方连接进来了
      let buffer = '';
      
      socket.on('data', (data) => {
        buffer += data.toString();
        // 尝试解析 JSON
        const lines = buffer.split('\n');
        buffer = lines.pop();
        
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const msg = JSON.parse(line);
            handleIncomingMessage(socket, msg);
          } catch (e) {
            // 非 JSON，可能是心跳
          }
        }
      });

      socket.on('error', (err) => {
        // 连接错误
      });

      socket.on('close', () => {
        // 连接关闭
      });
    });

    server.on('error', (err) => {
      reject(err);
    });

    server.listen(port, () => {
      console.log(`🦞 P2P 服务器已启动，监听端口 ${port}`);
      resolve(port);
    });

    messageHandler = onMessage;
  });
}

// 处理 incoming 消息
function handleIncomingMessage(socket, msg) {
  if (msg.type === 'handshake') {
    // 握手请求
    const config = loadConfig();
    const response = {
      type: 'handshake_ack',
      deviceId: DEVICE_ID,
      nickname: config.nickname,
      tags: config.tags,
    };
    socket.write(JSON.stringify(response) + '\n');
    
    // 保存联系人
    const contacts = loadContacts();
    contacts[msg.deviceId] = {
      address: socket.remoteAddress,
      port: msg.port || null,
      nickname: msg.nickname,
      tags: msg.tags || [],
      lastSeen: Date.now(),
    };
    saveContacts(contacts);
    
    console.log(`🤝 收到新连接: ${msg.nickname} (${msg.deviceId})`);
  } else if (msg.type === 'chat') {
    // 聊天消息
    console.log(`💬 收到消息 from ${msg.from}: ${msg.content}`);
    if (messageHandler) {
      messageHandler(msg.from, msg.nickname, msg.content);
    }
  }
}

// 连接到对方
function connectAndSend(targetIp, targetPort, message) {
  return new Promise((resolve, reject) => {
    const config = loadConfig();
    const socket = net.createConnection({ host: targetIp, port: targetPort }, () => {
      // 发送握手
      const handshake = {
        type: 'handshake',
        deviceId: DEVICE_ID,
        nickname: config.nickname,
        tags: config.tags,
        port: config.port,
      };
      socket.write(JSON.stringify(handshake) + '\n');
      
      // 等待握手响应
      let buffer = '';
      const handshakeHandler = (data) => {
        buffer += data.toString();
        const lines = buffer.split('\n');
        buffer = lines.pop();
        
        for (const line of lines) {
          if (!line.trim()) continue;
          try {
            const resp = JSON.parse(line);
            if (resp.type === 'handshake_ack') {
              socket.removeListener('data', handshakeHandler);
              
              // 保存联系人
              const contacts = loadContacts();
              contacts[resp.deviceId] = {
                address: targetIp,
                port: targetPort,
                nickname: resp.nickname,
                tags: resp.tags || [],
                lastSeen: Date.now(),
              };
              saveContacts(contacts);
              
              // 发送消息
              const chatMsg = {
                type: 'chat',
                from: DEVICE_ID,
                nickname: config.nickname,
                content: message,
              };
              socket.write(JSON.stringify(chatMsg) + '\n');
              
              setTimeout(() => {
                socket.end();
                resolve({ success: true, nickname: resp.nickname });
              }, 100);
            }
          } catch (e) {}
        }
      };
      socket.on('data', handshakeHandler);
    });

    socket.on('error', (err) => {
      reject(err);
    });

    socket.setTimeout(5000, () => {
      socket.destroy();
      reject(new Error('连接超时'));
    });
  });
}

// 获取本节点信息
function getMyInfo() {
  const config = loadConfig();
  return {
    deviceId: DEVICE_ID,
    nickname: config.nickname,
    tags: config.tags,
    port: config.port,
  };
}

// 获取联系人列表
function getContacts() {
  return loadContacts();
}

// 设置昵称
function setNickname(name) {
  const config = loadConfig();
  config.nickname = name;
  saveConfig(config);
  return config;
}

// 设置标签
function setTags(tags) {
  const config = loadConfig();
  config.tags = tags;
  saveConfig(config);
  return config;
}

// 停止服务器
function stopServer() {
  return new Promise((resolve) => {
    if (server) {
      server.close(() => {
        server = null;
        resolve();
      });
    } else {
      resolve();
    }
  });
}

module.exports = {
  startServer,
  stopServer,
  connectAndSend,
  getMyInfo,
  getContacts,
  setNickname,
  setTags,
  DEFAULT_PORT,
};
